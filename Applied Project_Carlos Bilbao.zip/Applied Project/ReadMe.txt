Simply un-zip the file. 
This is the applied project assignment for programming design.
The task was to create a python program that takes a customer's order and generates a price, it included:
- Flowcharts design
- Data dictionary design
- Hierarchy diagrams 
- Pseudocode
- Top-down approach to programming

Applied project 1 consists of:
Part A - Design
Part B - Implementation

Applied project 2 consists of:
An extended modularised version of applied project 1.