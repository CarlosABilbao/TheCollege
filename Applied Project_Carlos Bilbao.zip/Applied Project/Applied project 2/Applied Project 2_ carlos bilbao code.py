HALLOUMI = 17
VEGETARIAN = 18
BEAN = 20
CHEESE = 2.5
AVOSOUR = 3.5
TOMATO = 1.5

def getBurgerChoice():
            burgerChoiceTaken = False
            while burgerChoiceTaken == False:
                        burgerType = input(str("Enter the type of burger you wish to purchase - Halloumi/Vegetarian/Bean :"))
                        if burgerType == 'Halloumi' or burgerType == 'Vegetarian' or burgerType == 'Bean':
                            burgerChoiceTaken = True

                        else:
                            print("Sorry, the price cannot be calculated as you have entered an invalid burger type.\nPlease try again.")
            return burgerType

def getBurgerFilling():
            burgerFillingTaken = False
            while burgerFillingTaken == False:
                        fillingType = input(str("Select extra filling from Cheese/AvoSour/Tomato:"))
                        if fillingType == 'Cheese' or fillingType == 'AvoSour' or fillingType == 'Tomato':
                            burgerFillingTaken = True

                        else:
                            print("Sorry, the price cannot be calculated as you have entered an invalid response for extra topping.\nPlease try again.")
            return fillingType

def priceAssign(burgerOrFilling,constant, price):
            if constant == burgerOrFilling:
                        return price
            else:
                        pass
def calculateOrderTotal(burgerCost,fillingCost):
            total = burgerCost + fillingCost
            return total


print("Hello and welcome to VegoFresh, before we get started here is the price menu:\nBURGERS:\n  HALLOUMI 17\n  VEGETARIAN = 18\n  BEAN = 20\nFILLINGS:\n  CHEESE = 2.5\n  AVOSOUR = 3.5\n  TOMATO = 1.5")
fillingCost = 0 
                         
burgerUpper = (getBurgerChoice()).upper()
burgerCost = priceAssign(burgerUpper,'HALLOUMI',HALLOUMI)or priceAssign(burgerUpper,'VEGETARIAN',VEGETARIAN)or priceAssign(burgerUpper,'BEAN',BEAN)
Extra = input("Do you need extra filling (Y/N):")
if Extra == 'Y' or Extra =='y':
            fillingUpper = (getBurgerFilling()).upper()
            fillingCost = priceAssign(fillingUpper,'CHEESE',CHEESE)or priceAssign(fillingUpper,'AVOSOUR',AVOSOUR)or priceAssign(fillingUpper,'TOMATO',TOMATO)

print('The cost of the Burger is $'+str(calculateOrderTotal(burgerCost,fillingCost)))

