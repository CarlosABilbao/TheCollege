Total = 0
HALLOUMI = 17
VEGETARIAN = 18
BEAN = 20
CHEESE = 2.5
AVOSOUR = 3.5
TOMATO = 1.5

BurgerType = input("Enter the type of burger you wish to purchase \
- Halloumi/Vegetarian/Bean :")

if BurgerType == 'Halloumi':
    Total = Total + HALLOUMI    
elif BurgerType == 'Vegetarian':
    Total = Total + VEGETARIAN
elif BurgerType == 'Bean':
    Total = Total + BEAN
else:
    print("Sorry, the price cannot be calculated as you have entered \
an invalid burger type.")
    quit()

Extra = input("Do you need extra filling (Y/N):")
if Extra == 'Y':
    ExtraFilling = input("Select extra filling from Cheese/AvoSour/\
Tomato:")

else:
    print('The cost of the Burger is $'+str(Total))
    quit()

if ExtraFilling == 'Cheese':
    Total = Total + CHEESE

elif ExtraFilling == 'AvoSour':
    Total = Total + AVOSOUR
    
elif ExtraFilling == 'Tomato':
    Total = Total + TOMATO
    
else:
    print("Sorry, the price cannot be calculated as you have entered \
an invalid response for extra topping.")
    quit()
    

print('The cost of the Burger is $'+str(Total))
quit()

